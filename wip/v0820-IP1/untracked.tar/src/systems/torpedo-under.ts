// 近すぎて船体の下を通過（v0.8.2 IP1。ユーザーの決め 2026-11-19「推奨通り知らせを出してください。でもメッセージは「近すぎて船体の下を通過」にしてください」）: 自艇の魚雷が
// まだ武装の前（走った距離 runM < 武装の距離 armingM＝hit_rate_model.torpedo_launch.arming_distance_m の 100 m）のうちに、狙える艦（出ていない艦＝凍結の core/torpedo-targets の
// scanTargets が命中に数える艦）の当たりのカプセル（凍結の core/torpedo-solver の pointHitsHull＝武装していれば当たった判定そのもの）に入った魚雷を 1 本につき 1 回だけ数える。
// systems/destroyer-step が凍結の systems/torpedo-pool の step の直後に呼ぶ（同じ位置・同じ円）。世界（魚雷・艦・乱数）は読むだけで変えない＝再生の世界は今のまま。数は HUD の 2 行目だけが読む。
// 魚雷の枠は 1 発で使い切る（プールは撃つたびに次の枠＝作り直さない）ので、枠ごとの旗は世界を作った時に 0 で、発射の時に戻す必要がない。確保は constructor だけ。武装した魚雷は見ない（100 m の間だけ）。
import type { TorpedoState } from '../core/torpedo';
import type { TorpedoTarget } from '../core/torpedo-targets';
import { pointHitsHull } from '../core/torpedo-solver';

export class TorpedoUnder {
  /** 枠ごとに数えた（1）か */
  private readonly seen: Uint8Array;
  /** 武装の前に船体の下を通った魚雷の数（夜の通し） */
  count = 0;

  constructor(capacity: number, private readonly armingM: number) {
    this.seen = new Uint8Array(capacity);
  }

  /** 固定ステップ（魚雷のプールの step の直後）。states はプールの枠・targets は同じステップの目標 */
  step(states: readonly TorpedoState[], targets: readonly TorpedoTarget[]): void {
    for (let i = 0; i < states.length && i < this.seen.length; i++) {
      const s = states[i]!;
      if (!s.active || s.resolved || s.runM >= this.armingM || this.seen[i] !== 0) continue;
      for (let k = 0; k < targets.length; k++) {
        const t = targets[k]!;
        if (t.out || !pointHitsHull(s.x, s.y, t.circles)) continue;
        this.seen[i] = 1;
        this.count++;
        break;
      }
    }
  }
}
