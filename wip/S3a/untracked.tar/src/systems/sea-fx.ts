// v0.7.0 S3a（アートと音①：コードで描く絵。spec-v0700 §5.1・§5.6・R3・R4・R5・R9）: 海の面の演出＝海の模様の TileSprite 1 枚・夜明けの光の Image 1 枚・月のきらめき（昼は白波）の Image の輪。
// - 海の模様は世界の座標に置く（R5。画面に貼るとカメラの追従の 1 フレーム遅れで陸・航跡に対して泳ぐ）: 位置は周期（1,024 m）の倍数、camera.worldView ＋ 余白を覆う大きさ。
//   動かすのは揃えた升が変わった時だけ（setPosition・setScale・setTileScale。WebGL の TileSprite は tilePosition・tileScale を書いても描き直さない）。局所の大きさは 128 × 64 px の
//   まま setScale で広げる（その canvas と GPU の写しを小さく。R21）。Canvas レンダラーでは出さない（毎フレーム描き直すため。spec §5.1）。
// - 光（dark・half・full・day）の tint と α、夜明けの段（WorldDawn.lightStep。0〜16）で昼の値へ。段が変わった時だけ書く。
// - 夜明けの光: setScrollFactor(0) の Image を画面より各辺 3% 大きく（揺れの縁）、深さは海の模様の直上＝陸・艇・艦・字の下（R3）。α ＝ 0.22 × sin(π × 段/16)（R4）。ズームが変わった時だけ大きさを書く。
// - きらめき: 世界の座標に N 個。画面＋余白の外へ出たら反対側へ（横ずれは絵だけの乱数 ART_SEED_GLINT＝世界の絵を作る時に new。R30）。ゆっくり明滅（R9）。昼（whitecaps）は白い泡の色。
// §7: 確保は constructor だけ。update は読んで書くだけ（配列・オブジェクトを作らない）。論理の状態には書かない（art-rules）。
import type Phaser from 'phaser';
import { dawnGlowAlpha, glintBlink, mixRgb, SEA_TILE_TEX_PX, seaCellInto, wrapInto } from '../assets/sea-shape';
import { SEA_LIGHT_STEPS } from '../config/dawn-config';
import { TEXTURE_KEYS } from '../config/game-config';
import {
  ART_SEED_GLINT, DAWN_GLOW_DEPTH, DAWN_GLOW_OVERSCAN, DAWN_GLOW_TEX_H, DAWN_GLOW_TEX_W, GLINT_ALPHA_MAX, GLINT_COLOR, GLINT_DEPTH, GLINT_H_M, GLINT_PERIOD_MIN_S, GLINT_TEX_H, GLINT_TEX_W,
  GLINT_W_M, RENDERER_WEBGL, SEA_ART_DEPTH, SEA_LIGHT_ART, SEA_TILE_LOCAL_H, SEA_TILE_LOCAL_W, SEA_TILE_PERIOD_M, SEA_VIEW_MARGIN_M, WHITECAP_ALPHA_MAX, WHITECAP_COLOR, type SeaLightArt,
} from '../config/sea-art-config';
import { SeededRng } from '../core/rng';
import type { MoonPhase } from '../core/visibility';

export class SeaFx {
  private readonly cam: Phaser.Cameras.Scene2D.Camera;
  private readonly tile: Phaser.GameObjects.TileSprite | null;
  private readonly glow: Phaser.GameObjects.Image;
  private readonly glints: Phaser.GameObjects.Image[] = [];
  private readonly gx: Float32Array;
  private readonly gy: Float32Array;
  private readonly gPeriod: Float32Array;
  private readonly gPhase: Float32Array;
  /** 升の [左, 上, 横の数, 縦の数]（周期の単位）。前の値と比べて変わった時だけ TileSprite を動かす */
  private readonly cell = new Int32Array(4);
  private readonly rng = new SeededRng(ART_SEED_GLINT);
  private readonly light: SeaLightArt;
  private readonly dayStart: boolean;
  private step = -1;
  private zoom = NaN;
  private cx = NaN;
  private cy = NaN;
  private nx = 0;
  private ny = 0;
  private t = 0;
  private placed = false;
  private glintBase = 0;

  constructor(scene: Phaser.Scene, moon: MoonPhase, dayStart: boolean) {
    this.cam = scene.cameras.main;
    this.light = SEA_LIGHT_ART[moon];
    this.dayStart = dayStart;
    const webgl = scene.sys.game.renderer.type === RENDERER_WEBGL;
    this.tile = webgl ? scene.add.tileSprite(0, 0, SEA_TILE_LOCAL_W, SEA_TILE_LOCAL_H, TEXTURE_KEYS.seaTile).setOrigin(0, 0).setDepth(SEA_ART_DEPTH).setVisible(false) : null;
    this.glow = scene.add.image(0, 0, TEXTURE_KEYS.dawnGlow).setScrollFactor(0).setDepth(DAWN_GLOW_DEPTH).setVisible(false);
    const n = this.light.glints;
    this.gx = new Float32Array(n);
    this.gy = new Float32Array(n);
    this.gPeriod = new Float32Array(n);
    this.gPhase = new Float32Array(n);
    const color = this.light.whitecaps ? WHITECAP_COLOR : GLINT_COLOR;
    for (let i = 0; i < n; i++) {
      this.glints.push(scene.add.image(0, 0, TEXTURE_KEYS.glint).setDepth(GLINT_DEPTH).setScale(GLINT_W_M / GLINT_TEX_W, GLINT_H_M / GLINT_TEX_H).setTint(color).setVisible(false));
      this.gPeriod[i] = this.rng.nextRange(GLINT_PERIOD_MIN_S, GLINT_PERIOD_MIN_S * 2);
      this.gPhase[i] = this.rng.next() * Math.PI * 2;
    }
  }

  /** 毎フレーム（world-art から。realDt は見た目の時計、step は WorldDawn.lightStep） */
  update(realDt: number, step: number): void {
    const cam = this.cam;
    const v = cam.worldView;
    if (!(v.width > 0)) return;
    this.t += realDt;
    if (step !== this.step) this.applyStep(step);
    if (cam.zoom !== this.zoom) this.applyZoom(cam.zoom);
    if (this.tile) {
      const c = this.cell;
      seaCellInto(c, v.x, v.y, v.width, v.height, SEA_TILE_PERIOD_M, SEA_VIEW_MARGIN_M);
      if (c[0] !== this.cx || c[1] !== this.cy || c[2] !== this.nx || c[3] !== this.ny) this.moveTile(c[0]!, c[1]!, c[2]!, c[3]!);
    }
    const n = this.glints.length;
    if (n === 0) return;
    if (!this.placed) this.place(v.x, v.y, v.width, v.height);
    const m = GLINT_W_M;
    for (let i = 0; i < n; i++) {
      const img = this.glints[i]!;
      img.setAlpha(this.glintBase * glintBlink(this.t, this.gPeriod[i]!, this.gPhase[i]!));
      const x0 = this.gx[i]!;
      const y0 = this.gy[i]!;
      const x1 = wrapInto(x0, v.x, v.right, m);
      const y1 = wrapInto(y0, v.y, v.bottom, m);
      if (x1 === x0 && y1 === y0) continue;
      // 反対側へ。横切った軸と直交する向きは画面の内で引き直す（同じ筋が同じ列に戻らない）
      this.gx[i] = x1 !== x0 ? x1 : v.x + this.rng.next() * v.width;
      this.gy[i] = y1 !== y0 ? y1 : v.y + this.rng.next() * v.height;
      img.setPosition(this.gx[i]!, this.gy[i]!);
    }
  }

  /** 最初のフレーム: 画面の内へ一様に */
  private place(x: number, y: number, w: number, h: number): void {
    this.placed = true;
    for (let i = 0; i < this.glints.length; i++) {
      this.gx[i] = x + this.rng.next() * w;
      this.gy[i] = y + this.rng.next() * h;
      this.glints[i]!.setPosition(this.gx[i]!, this.gy[i]!).setVisible(this.glintBase > 0);
    }
  }

  /** 升が変わった時だけ: 位置は周期の倍数、大きさは升の数 × 周期、模様の周期は世界で 1,024 m のまま */
  private moveTile(cx: number, cy: number, nx: number, ny: number): void {
    this.cx = cx;
    this.cy = cy;
    this.nx = nx;
    this.ny = ny;
    const P = SEA_TILE_PERIOD_M;
    this.tile!.setPosition(cx * P, cy * P).setScale((nx * P) / SEA_TILE_LOCAL_W, (ny * P) / SEA_TILE_LOCAL_H).setTileScale(SEA_TILE_LOCAL_W / (SEA_TILE_TEX_PX * nx), SEA_TILE_LOCAL_H / (SEA_TILE_TEX_PX * ny)).setVisible(true);
  }

  /** 段が変わった時だけ: 模様の tint と α（光 → 昼）、夜明けの光の α、きらめきの α の上限（月のきらめきは昼へ向けて薄く。白波はそのまま） */
  private applyStep(step: number): void {
    this.step = step;
    const f = step <= 0 ? 0 : step >= SEA_LIGHT_STEPS ? 1 : step / SEA_LIGHT_STEPS;
    const day = SEA_LIGHT_ART.day;
    const L = this.light;
    this.tile?.setTint(mixRgb(L.crest, day.crest, f)).setAlpha(L.crestAlpha + (day.crestAlpha - L.crestAlpha) * f);
    const a = dawnGlowAlpha(step, SEA_LIGHT_STEPS, this.dayStart);
    this.glow.setAlpha(a).setVisible(a > 0);
    this.glintBase = L.whitecaps ? WHITECAP_ALPHA_MAX : GLINT_ALPHA_MAX * (1 - f);
    if (this.placed) for (const g of this.glints) g.setVisible(this.glintBase > 0);
  }

  /** ズームが変わった時だけ: 夜明けの光を画面（＋各辺 3%）に広げる。scrollFactor 0 の物は (x − 幅/2) × zoom ＋ 幅/2 に出るので、中心に置いて 1/zoom 倍 */
  private applyZoom(zoom: number): void {
    this.zoom = zoom;
    const cam = this.cam;
    const k = (1 + 2 * DAWN_GLOW_OVERSCAN) / zoom;
    this.glow.setPosition(cam.width / 2, cam.height / 2).setScale((cam.width * k) / DAWN_GLOW_TEX_W, (cam.height * k) / DAWN_GLOW_TEX_H);
  }

  destroy(): void {
    this.tile?.destroy();
    this.glow.destroy();
    for (const g of this.glints) g.destroy();
    this.glints.length = 0;
  }
}
