// 性能の計測（v0.6.11 S7。spec-v0611-r2 §11「測り方」）: ヘッドレスで jp_03 ハードを偽の時計・固定ステップ 1/60 秒のまま回し、毎フレーム描いて、
// フレームごとの壁時計（performance.now() の差）を測る。比べる基準は同じ台本の jp_04 ハード（夜明けの空襲の第 2 波）。ゲームは import しない（開発の道具だけ）。
// 測る物（フレーム k ごと）:
//   - 進める（__hl.frame＝game.headlessStep。Mission と Hud の update＝入力の消費・固定ステップ・見た目の同期・HUD）と、その中の世界の updateFrame・固定ステップ 1 つ（stepFn）
//   - 描く（__hl.render＝game.step(t, 0)。delta 0 の update と描画）。フレーム＝進める ＋ 描く
//   - Mission の scene.children.length（30 秒ごとの最小値。爆発の絵は Image と tween を作って消すので毎フレームの数は揺れる＝最小値が増えなければ漏れが無い。r2 L5）
//   - Text.setText の呼ばれた回数（全部の Scene の Text。前回値と同じ文で呼んだ回も数える）と、文が変わった回数
//   - 飛んでいる機（凍結の空襲の AirPlane の段 1〜5＝来る・回る・爆撃進路・抜ける・去る）の数・動く編隊の数・2 回目（もう一度来る編隊）の動く数（jp_03）
// 窓: jp_03 は t 190〜225 秒（第 4 波＝ハードは 4 機の編隊が 3 つ同時。spec §11）、jp_04 は夜明けの空襲の第 2 波が飛んでいるフレーム。ほかに 30 秒ごとの表。
// 台本（jp_03・jp_04 で同じ）: weave（既定）＝夜明けのラッチ（jp_03 は 240 秒の決着・jp_04 は 160 秒の夜明け）まではスティック中立・何も押さない（模擬の stay と同じ＝jp_03 は全部の隊が外のまま）、
//   その後は全速で 4 秒ごとに 90° ずつ向きを変える（jp_04 の自艇が夜明けの空襲の第 1 波で沈まずに第 2 波まで浮くため）。still＝最後まで中立。
// 描くのは窓（jp_03 は t 185〜230 秒・jp_04 は夜明けの後）の中は毎フレーム、外は 10 フレームに 1 回（ヘッドレスの描画は CPU で遅い。描く秒は窓の中だけ数える）。
// 門（spec §11）: jp_03 の窓のフレームの p95 ≤ jp_04 の窓の p95 × 1.5、30 秒ごとの children の最小値が増えない、setText ≤ 平均 10 回/秒。数はヘッドレスの相対値（iPhone の FPS は実機テスト 3）。
// 実行: VITE_BASE=/ww2-torpedo-boat/ npm run build -- --outDir <site> の後
//   SITE=<site> [WS=1560,1280] [SEED=1] [SEED04=1] [POL=weave] [POL04=weave] [SECS=240] [SECS04=240] [ONLY=jp03|jp04] [OUT=<json>] node scripts/headless/evac-perf.mjs
import { writeFileSync } from 'node:fs';
import { FRAME_MS, chromium, envNum, openGame, serve } from './lib.mjs';

/** ページの中: 計測の包みを 1 回だけ入れる（世界の updateFrame と stepFn・Text の setText の原型） */
function installProbe() {
  const hl = window.__hl;
  const w = hl.world();
  const pr = { uf: 0, steps: [], calls: 0, changed: 0 };
  const uf = w.updateFrame.bind(w);
  w.updateFrame = (dt) => { const a = performance.now(); uf(dt); pr.uf += performance.now() - a; };
  const sf = w.stepFn;
  w.stepFn = (dt) => { const a = performance.now(); sf(dt); pr.steps.push(performance.now() - a); };
  let proto = null;
  for (const key of ['Hud', 'Mission']) {
    const s = window.__game.scene.getScene(key);
    for (const o of s.children.list) if (o.type === 'Text') { proto = Object.getPrototypeOf(o); break; }
    if (proto) break;
  }
  if (!proto) throw new Error('Text が見つからない');
  while (proto && !Object.prototype.hasOwnProperty.call(proto, 'setText')) proto = Object.getPrototypeOf(proto);
  const st = proto.setText;
  proto.setText = function (v) { pr.calls++; if (String(v ?? '') !== this._text) pr.changed++; return st.call(this, v); };
  window.__perf = pr;
}

/** ページの中: n フレームを台本で進めて毎フレーム描く。フレームごとの数を返す（任務が終われば止める） */
function playFrames(o) {
  const hl = window.__hl;
  const pr = window.__perf;
  const out = { upd: [], uf: [], step: [], stepSum: [], stepN: [], render: [], children: [], planes: [], live: [], again: [], wave: [], calls: [], changed: [], t: [], alive: true, iso: window.crossOriginIsolated === true };
  const flying = (st) => { let n = 0; for (const p of st.planes) if (p.phase >= 1 && p.phase <= 5) n++; return n; };
  for (let i = 0; i < o.n; i++) {
    if (!hl.active('Mission')) { out.alive = false; break; }
    const w = hl.world();
    const k = Math.round(w.stepTimeS * 60);
    if (o.pol === 'weave' && w.dawn.reached) hl.steer((Math.floor(k / 240) * 90) % 360, 1);
    else hl.steer(NaN, 0);
    w.input.gunHeld = false;
    const c0 = pr.calls;
    const g0 = pr.changed;
    pr.uf = 0;
    pr.steps.length = 0;
    const a = performance.now();
    hl.frame(o.frameMs);
    const b = performance.now();
    if (!hl.active('Mission')) { out.alive = false; break; }
    // 描くのは窓の中は毎フレーム、外は o.every フレームに 1 回（ヘッドレスの描画は CPU で遅い。窓の外の描く秒は数えない）
    const t = w.stepTimeS;
    const all = o.kind === 'jp03' ? t >= o.r0 && t <= o.r1 : w.dawn.reached;
    let c = b;
    if (all || k % o.every === 0) { hl.render(); c = performance.now(); }
    out.upd.push(b - a);
    out.uf.push(pr.uf);
    let ss = 0;
    for (const x of pr.steps) ss += x;
    out.step.push(pr.steps.length > 0 ? ss / pr.steps.length : NaN);
    out.stepSum.push(ss);
    out.stepN.push(pr.steps.length);
    out.render.push(all ? c - b : NaN);
    out.children.push(hl.mission().children.list.length);
    out.calls.push(pr.calls - c0);
    out.changed.push(pr.changed - g0);
    out.t.push(w.stepTimeS);
    let planes = 0;
    let live = 0;
    let again = 0;
    let wave = -1;
    if (w.evac) {
      for (const fl of w.evac.plan.flights) {
        const st = fl.port.state;
        if (!(st.started && !st.cancelled)) continue;
        const n = flying(st);
        if (n === 0) continue;
        planes += n;
        live++;
        if (fl.passes >= 2) again++;
        wave = Math.max(wave, fl.wave);
      }
    } else if (w.dawn.strike) {
      const st = w.dawn.strike.state;
      if (st.started && !st.cancelled) { planes = flying(st); live = planes > 0 ? 1 : 0; wave = st.waves; }
    }
    out.planes.push(planes);
    out.live.push(live);
    out.again.push(again);
    out.wave.push(wave);
  }
  return out;
}

const q = (xs, p) => { if (xs.length === 0) return NaN; const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
const f2 = (x) => (Number.isFinite(x) ? x.toFixed(2) : '—');
const stats = (xs) => ({ p50: q(xs, 0.5), p95: q(xs, 0.95), p99: q(xs, 0.99), max: xs.length ? Math.max(...xs) : NaN, n: xs.length });
const fmt = (s, unit = 'ms') => `p50 ${f2(s.p50)}・p95 ${f2(s.p95)}・p99 ${f2(s.p99)}・最大 ${f2(s.max)} ${unit}`;

/** 1 夜を回す（chunk 600 フレームずつ） */
async function oneRun(browser, base, c) {
  const { page, ctx, errors } = await openGame(browser, base, c.query, { width: c.width });
  const all = { upd: [], uf: [], step: [], stepSum: [], stepN: [], render: [], children: [], planes: [], live: [], again: [], wave: [], calls: [], changed: [], t: [] };
  let alive = true;
  let iso = false;
  try {
    await page.evaluate(installProbe);
    for (let done = 0; done < c.secs * 60 && alive; done += 600) {
      const r = await page.evaluate(playFrames, { n: Math.min(600, c.secs * 60 - done), frameMs: FRAME_MS, pol: c.pol, kind: c.kind, r0: 185, r1: 230, every: 10 });
      for (const k of Object.keys(all)) all[k].push(...r[k]);
      alive = r.alive;
      iso = r.iso;
    }
  } finally {
    await ctx.close();
  }
  return { ...c, ...all, alive, iso, errors };
}

/** 窓のフレームの番号 */
function windowIdx(r) {
  const idx = [];
  for (let i = 0; i < r.t.length; i++) {
    if (r.kind === 'jp03' ? r.t[i] >= 190 && r.t[i] <= 225 : r.wave[i] === 2 && r.planes[i] > 0) idx.push(i);
  }
  return idx;
}

function report(r) {
  const frame = r.upd.map((x, i) => x + r.render[i]); // 描いていないフレームは NaN（窓の外）
  const idx = windowIdx(r);
  const pick = (xs) => idx.map((i) => xs[i]).filter((x) => Number.isFinite(x));
  const win = {
    frame: stats(pick(frame)), upd: stats(pick(r.upd)), uf: stats(pick(r.uf)), render: stats(pick(r.render)), step: stats(pick(r.step).map((x) => x * 1000)),
    stepMean: (idx.reduce((s, i) => s + r.stepSum[i], 0) / Math.max(1, idx.reduce((s, i) => s + r.stepN[i], 0))) * 1000,
    planesMax: Math.max(0, ...pick(r.planes)), s12: pick(r.planes).filter((x) => x >= 12).length / 60, liveMax: Math.max(0, ...pick(r.live)), againMax: Math.max(0, ...pick(r.again)),
    t0: idx.length ? r.t[idx[0]] : NaN, t1: idx.length ? r.t[idx[idx.length - 1]] : NaN,
  };
  const secs = r.t.length / 60;
  const per30 = [];
  for (let a = 0; a < secs; a += 30) {
    const ii = [];
    for (let i = 0; i < r.t.length; i++) if (r.t[i] > a && r.t[i] <= a + 30) ii.push(i);
    if (ii.length === 0) continue;
    const ch = Math.min(...ii.map((i) => r.children[i]));
    const calls = ii.reduce((s, i) => s + r.calls[i], 0) / (ii.length / 60);
    const changed = ii.reduce((s, i) => s + r.changed[i], 0) / (ii.length / 60);
    per30.push({ a, b: a + 30, p95: q(ii.map((i) => r.upd[i]), 0.95), stepMean: (ii.reduce((s, i) => s + r.stepSum[i], 0) / Math.max(1, ii.reduce((s, i) => s + r.stepN[i], 0))) * 1000, stepP95: q(ii.map((i) => r.step[i] * 1000).filter((x) => Number.isFinite(x)), 0.95), ch, chMax: Math.max(...ii.map((i) => r.children[i])), calls, changed, planesMax: Math.max(...ii.map((i) => r.planes[i])), againMax: Math.max(...ii.map((i) => r.again[i])) });
  }
  const callsAvg = r.calls.reduce((s, x) => s + x, 0) / secs;
  const changedAvg = r.changed.reduce((s, x) => s + x, 0) / secs;
  // 漏れの見方: 30 秒ごとの最小値が前の窓の最小値を超えない（最初の 30 秒は生成の途中の物を含むので 30 秒以降を比べる）
  let leak = false;
  for (let i = 2; i < per30.length; i++) if (per30[i].ch > per30[i - 1].ch) leak = true;
  return { win, per30, callsAvg, changedAvg, secs, leak };
}

async function main() {
  const site = process.env.SITE;
  if (!site) throw new Error('SITE=<ビルドした site のディレクトリ> が要る');
  const ws = (process.env.WS ?? '1560,1280').split(',').map(Number);
  const only = process.env.ONLY ?? '';
  const cases = [];
  for (const width of ws) {
    if (only !== 'jp04') cases.push({ kind: 'jp03', width, pol: process.env.POL ?? 'weave', secs: envNum('SECS', 240), query: `mission=jp_03&seed=${envNum('SEED', 1)}&hard` });
    if (only !== 'jp03') cases.push({ kind: 'jp04', width, pol: process.env.POL04 ?? 'weave', secs: envNum('SECS04', 240), query: `mission=jp_04&seed=${envNum('SEED04', 1)}&hard` });
  }
  const sv = await serve(site, { isolate: true }); // performance.now を 5 μs 刻みに（crossOriginIsolated）
  const browser = await chromium.launch();
  const res = [];
  // 1 夜ずつ順に（並べると壁時計が互いに乱れる）
  for (const c of cases) res.push(await oneRun(browser, sv.base, c));
  await browser.close();
  await sv.close();
  const rows = [];
  let bad = 0;
  for (const r of res) {
    const rep = report(r);
    rows.push({ kind: r.kind, width: r.width, pol: r.pol, query: r.query, alive: r.alive, frames: r.t.length, errors: r.errors, ...rep });
    const w = rep.win;
    console.log(`[${r.query} W ${r.width} ${r.pol}] ${r.t.length} フレーム（${rep.secs.toFixed(1)} 秒${r.alive ? '' : '・任務が終わった'}）・crossOriginIsolated ${r.iso}・page errors ${r.errors.length}${r.errors.length ? `: ${r.errors[0]}` : ''}`);
    console.log(`  窓 ${f2(w.t0)}〜${f2(w.t1)} 秒: フレーム（進める＋描く）${fmt(w.frame)} | 進める ${fmt(w.upd)} | updateFrame ${fmt(w.uf)} | 描く ${fmt(w.render)} | 固定ステップ 1 つ 平均 ${f2(w.stepMean)}・${fmt(w.step, 'μs')}`);
    console.log(`  窓の機: 飛ぶ機の最大 ${w.planesMax}・12 機の秒 ${f2(w.s12)}・動く編隊の最大 ${w.liveMax}・動く 2 回目の編隊の最大 ${w.againMax}`);
    console.log(`  setText: 平均 ${f2(rep.callsAvg)} 回/秒（文が変わった ${f2(rep.changedAvg)} 回/秒）${rep.callsAvg <= 10 ? '' : ' ✗（> 10）'}・30 秒ごとの children の最小値 ${rep.per30.map((p) => p.ch).join(' → ')}${rep.leak ? ' ✗（増えた）' : '（増えない）'}`);
    for (const p of rep.per30) console.log(`    ${String(p.a).padStart(3)}〜${String(p.b).padStart(3)} 秒: 進める p95 ${f2(p.p95)} ms・ステップ 平均 ${f2(p.stepMean)}・p95 ${f2(p.stepP95)} μs・children ${p.ch}〜${p.chMax}・setText ${f2(p.calls)}（変わった ${f2(p.changed)}）回/秒・機の最大 ${p.planesMax}・2 回目の編隊 ${p.againMax}`);
    if (r.errors.length > 0 || rep.leak || rep.callsAvg > 10) bad++;
  }
  for (const width of ws) {
    const a = rows.find((x) => x.kind === 'jp03' && x.width === width);
    const b = rows.find((x) => x.kind === 'jp04' && x.width === width);
    if (!a || !b) continue;
    const ok = a.win.frame.p95 <= b.win.frame.p95 * 1.5;
    if (!ok) bad++;
    console.log(`W ${width}: jp_03 の窓の p95 ${f2(a.win.frame.p95)} ms ≤ jp_04 の窓の p95 ${f2(b.win.frame.p95)} × 1.5 ＝ ${f2(b.win.frame.p95 * 1.5)} ${ok ? '✓' : '✗'}（updateFrame の p95 ${f2(a.win.uf.p95)}／${f2(b.win.uf.p95)} ms）`);
  }
  console.log(`runs ${rows.length} bad ${bad}`);
  if (process.env.OUT) writeFileSync(process.env.OUT, JSON.stringify(rows, null, 1));
  process.exitCode = bad === 0 ? 0 : 1;
}

await main();
