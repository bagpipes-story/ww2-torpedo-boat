// v0.8.5 S2（us_07「D-Day・生存者救助」）の絵の定数: 生存者の群・機雷・水路のブイ・機雷原と水路の帯・フィッチとコリーの見せ方・フィッチの砲火の見せ方（systems/rescue-view・assets/rescue-art）。
// CLAUDE.md §2「アート」: コードで描く（外部の画像を使わない）。ゲームの強さの値ではないので data/*.json には置かない（論理に効く拾う距離・機雷の数・輪の半径は data のまま）。何も import しない。
// 色の意味は固定（docs/02 §7）: 味方＝薄い青（フィッチ・コリー・輪）、敵の危険＝赤（機雷の輪・機雷原の帯）、生存者＝救命胴衣の橙。

/** 絵のテクスチャの鍵（Boot が救助の任務のある時に 1 回。生存者は人数ごとの frame p0〜p7＝1〜8 名・ブイは p0 赤（左舷）・p1 緑（右舷）） */
export const RESCUE_TEX_SURVIVORS = 'tex-survivors';
export const RESCUE_TEX_MINE = 'tex-mine';
export const RESCUE_TEX_BUOY = 'tex-buoy';
/** 味方のフレッチャー級（フィッチと沈むコリー）の鍵（assets/destroyer-art の paintAllyFletcherTexture。寸法は RESCUE_SHIP_ENEMY_ID の記録） */
export const RESCUE_TEX_ALLY_SHIP = 'tex-destroyer-ally-us';
/** フィッチとコリーの絵の寸法を取る記録（enemies.json のフレッチャー級。当たりは無い＝絵だけ） */
export const RESCUE_SHIP_ENEMY_ID = 'us_destroyer';
/** テクスチャの密度（1 世界単位の px ＝ RENDER_SCALE × これ。艇の絵と同じ 2） */
export const RESCUE_TEX_DENSITY = 2;

/** 生存者の群の絵: 一辺（単位）・人数の上限（これより多い群はこの数で描く）・人の救命胴衣と頭の半径・その下の泡の半径と濃さ・群の周りの波立ちの半径と濃さ・人の置き方（中心からの単位。多い順に足す） */
export const SURVIVOR_TEX_UNITS = 44;
export const SURVIVOR_HEADS_MAX = 8;
export const SURVIVOR_VEST_R = 2.8;
export const SURVIVOR_HEAD_R = 1.2;
export const SURVIVOR_FOAM_R = 4;
export const SURVIVOR_FOAM_ALPHA = 0.35;
export const SURVIVOR_RIPPLE_R = 20;
export const SURVIVOR_RIPPLE_ALPHA = 0.16;
export const SURVIVOR_SPOTS: readonly (readonly [number, number])[] = [[0, 0], [7, -3], [-6, 4], [3, 8], [-4, -8], [11, 5], [-11, -2], [6, -11]];
export const SURVIVOR_VEST_COLOR = 0xff9a3c;
export const SURVIVOR_HEAD_COLOR = 0x5a3a28;
/** 群の人数の札（世界の字。人数が変わった時だけ setText）: 群の中心からの下へのずれ（単位）・字の大きさ・色 */
export const SURVIVOR_LABEL_DY = 24;
export const SURVIVOR_LABEL_FONT_PX = 22;
export const SURVIVOR_LABEL_COLOR = '#ffd9b0';

/** 機雷（見えた物だけ）: 一辺（単位）・球の半径・角の数と長さ・赤い警告の輪の半径と線と濃さ・色 */
export const MINE_TEX_UNITS = 44;
export const MINE_BALL_R = 7;
export const MINE_HORNS = 5;
export const MINE_HORN_UNITS = 2.8;
export const MINE_RING_R = 19;
export const MINE_RING_LINE = 2.6;
export const MINE_RING_ALPHA = 0.85;
export const MINE_BALL_COLOR = 0x3b3330;
export const MINE_RIM_COLOR = 0x8a7a70;
export const MINE_RING_COLOR = 0xff5a4a;

/** 水路のブイ: 一辺（単位）・半径・縁・左舷（赤）と右舷（緑）の色・水路に沿う間隔 m（両端も置く。合計の上限 BUOY_MAX）・帯の縁から内への寄せ m */
export const BUOY_TEX_UNITS = 20;
export const BUOY_R = 6.5;
export const BUOY_RIM = 1.6;
export const BUOY_RED = 0xd8453b;
export const BUOY_GREEN = 0x3fa15a;
export const BUOY_SPACING_M = 420;
export const BUOY_MAX = 24;
export const BUOY_INSET_M = 10;

/** 水路の帯（任務の開始に 1 回描く Graphics）と機雷原の区画の薄い色: 色と濃さ */
export const LANE_FILL_COLOR = 0xbfe6ff;
export const LANE_FILL_ALPHA = 0.07;
export const MINEFIELD_FILL_COLOR = 0xff6a5a;
export const MINEFIELD_FILL_ALPHA = 0.05;
export const MINEFIELD_LINE_ALPHA = 0.22;
export const MINEFIELD_LINE_W = 3;

/** フィッチ: 輪の色（味方の青）と濃さ・艦名の字の大きさ・色・艦の下へのずれ（単位） */
export const FITCH_RING_COLOR = 0x9ad0ff;
export const FITCH_RING_ALPHA = 0.55;
export const SHIP_LABEL_FONT_PX = 24;
export const SHIP_LABEL_COLOR = '#b8e0ff';
export const SHIP_LABEL_GAP = 20;
/** コリーの名の下へのずれ（単位。南の群の札と重ならないように遠く） */
export const CORRY_LABEL_GAP = 80;
/** 沈んでいくコリー: 暗くする tint・初めと救助の時間の終わりの濃さ（濃さの段の数＝変わった時だけ setAlpha）・横から見た傾き（幅の縮み）・艦首を下げる回り（度）・油の輪の半径 m と濃さ */
export const CORRY_TINT = 0xa9b6c2;
export const CORRY_ALPHA_FROM = 0.95;
export const CORRY_ALPHA_TO = 0.5;
export const CORRY_LIST_SCALE_X = 0.82;
export const CORRY_SETTLE_DEG = 4;
export const CORRY_ALPHA_STEPS = 24;
export const CORRY_OIL_RADIUS_M = 110;
export const CORRY_OIL_ALPHA = 0.32;

/** フィッチの砲火の見せ方（絵だけ・乱数なし）: S ボートがフィッチの砲火の距離の内に居る間の発砲の間隔（実秒）と、S ボートの周りの水柱の決まった 4 点（S ボートからの m） */
export const FITCH_FIRE_INTERVAL_S = 0.9;
export const FITCH_SPLASH_OFFSETS: readonly (readonly [number, number])[] = [[60, -40], [-50, 30], [35, 55], [-40, -60]];
